package api

import (
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"
)

// Client-only guard: every non-API request must present a session cookie
// minted from a paired client key. The client proves itself with a short
// HMAC over (timestamp | machine) using a key it received at pairing time,
// sent once as query params on its first navigation; the server validates
// and issues an HttpOnly session cookie for the rest of the session.
//
// A pairing key is machine-bound. Spoofing therefore requires BOTH the
// paired key file AND knowledge of the machine profile — "hard", not
// impossible (any binary-held secret can be extracted in principle; for
// full spoof-immunity bind the UI listener to loopback and let only the
// client process reach it).
//
// /api/v1/**, /healthz, /scan.html and /pair-guide.* stay open: the API
// keeps its own bearer-token protection and the pairing page must load
// before a session exists.

const (
	clientCookieName = "ckdpair"
	proofWindowSec   = 300
)

type clientKeyEntry struct {
	Key       string    `json:"key"`
	Machine   string    `json:"machine"`
	Name      string    `json:"name"`
	CreatedAt time.Time `json:"createdAt"`
}

type clientKeyStore struct {
	PairCode string                    `json:"pairCode"`
	Keys     map[string]clientKeyEntry `json:"keys"`
}

type ClientGuard struct {
	enabled bool
	file    string
	mu      sync.Mutex
	store   clientKeyStore
	sess    map[string]clientSession
	pairLim *RateLimiter
	logger  interface{ Printf(string, ...any) }
}

type clientSession struct {
	clientID string
	machine  string
	expires  time.Time
}

func NewClientGuard(enabled bool, keysFile string, logger interface{ Printf(string, ...any) }) *ClientGuard {
	return &ClientGuard{
		enabled: enabled,
		file:    keysFile,
		sess:    map[string]clientSession{},
		pairLim: NewRateLimiter(),
		logger:  logger,
	}
}

func (g *ClientGuard) Enabled() bool { return g.enabled }

// Init loads (or creates) the key store. On first creation a fresh pairing
// code is generated and printed to the server log once.
func (g *ClientGuard) Init() error {
	if !g.enabled {
		return nil
	}
	g.mu.Lock()
	defer g.mu.Unlock()
	if raw, err := os.ReadFile(g.file); err == nil {
		var st clientKeyStore
		if json.Unmarshal(raw, &st) == nil && st.Keys != nil {
			g.store = st
			if g.logger != nil && st.PairCode != "" {
				g.logger.Printf("[cockpit] client-only mode: pairing code ready (use POST /api/v1/pair)")
			}
			return nil
		}
	}
	g.store = clientKeyStore{PairCode: randClientCode(), Keys: map[string]clientKeyEntry{}}
	if err := g.saveLocked(); err != nil {
		return err
	}
	if g.logger != nil {
		g.logger.Printf("[cockpit] client-only mode enabled — PAIRING CODE: %s (one-time; pair clients before browsing)", g.store.PairCode)
	}
	return nil
}

func (g *ClientGuard) saveLocked() error {
	raw, err := json.MarshalIndent(g.store, "", "  ")
	if err != nil {
		return err
	}
	tmp := g.file + ".tmp"
	if err := os.WriteFile(tmp, raw, 0600); err != nil {
		return err
	}
	return os.Rename(tmp, g.file)
}

func randClientCode() string {
	b := make([]byte, 5)
	ll := []byte("ABCEFMNPQRSTUVXYZ23456789") // unambiguous alphabet
	rand.Read(b)
	code := make([]byte, 0, 9)
	for i := 0; i < 4; i++ {
		code = append(code, ll[int(b[i])%len(ll)])
	}
	code = append(code, '-')
	for i := 2; i < 5; i++ {
		code = append(code, ll[int(b[i])%len(ll)])
	}
	code = append(code, ll[int(b[0]+b[3])%len(ll)])
	return string(code)
}

func randHex(n int) string {
	b := make([]byte, n)
	rand.Read(b)
	return hex.EncodeToString(b)
}

// Paths the guard never blocks.
func openPath(p string) bool {
	if p == "/healthz" || p == "/scan.html" || p == "/pair-guide.html" || p == "/js/pairguide.js" {
		return true
	}
	for _, pre := range []string{"/api/", "/js/pairguide.js"} {
		if strings.HasPrefix(p, pre) {
			return true
		}
	}
	return false
}

// Wrap enforces the guard around the whole mux when enabled.
func (g *ClientGuard) Wrap(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if !g.enabled || openPath(r.URL.Path) {
			next.ServeHTTP(w, r)
			return
		}
		// 1) already-sessioned client?
		if c, err := r.Cookie(clientCookieName); err == nil {
			if g.sessionValid(c.Value) {
				next.ServeHTTP(w, r)
				return
			}
		}
		// 2) fresh proof on the navigation URL?
		if r.Method == http.MethodGet && g.validateProof(r) {
			tok := randHex(16)
			g.mu.Lock()
			g.sess[tok] = clientSession{
				clientID: r.URL.Query().Get("ckid"),
				machine:  r.URL.Query().Get("mach"),
				expires:  time.Now().Add(12 * time.Hour),
			}
			cutoff := time.Now().Add(-12 * time.Hour)
			for k, s := range g.sess {
				if s.expires.Before(cutoff) {
					delete(g.sess, k)
				}
			}
			g.mu.Unlock()
			http.SetCookie(w, &http.Cookie{
				Name:     clientCookieName,
				Value:    tok,
				Path:     "/",
				HttpOnly: true,
				SameSite: http.SameSiteStrictMode,
			})
			target := r.URL.Path
			if q := r.URL.Query(); len(q) > 0 {
				q.Del("ckid")
				q.Del("ts")
				q.Del("mach")
				q.Del("proof")
				if enc := q.Encode(); enc != "" {
					target += "?" + enc
				}
			}
			http.Redirect(w, r, target, http.StatusFound)
			return
		}
		g.writeBlocked(w)
	})
}

func (g *ClientGuard) sessionValid(token string) bool {
	if token == "" {
		return false
	}
	g.mu.Lock()
	defer g.mu.Unlock()
	s, ok := g.sess[token]
	if !ok || s.expires.Before(time.Now()) {
		return false
	}
	return true
}

// validateProof checks ckid/ts/mach against the stored key's HMAC.
func (g *ClientGuard) validateProof(r *http.Request) bool {
	ckid := r.URL.Query().Get("ckid")
	ts := r.URL.Query().Get("ts")
	mach := r.URL.Query().Get("mach")
	proof := r.URL.Query().Get("proof")
	if ckid == "" || ts == "" || proof == "" || mach == "" {
		return false
	}
	t, err := strconv.ParseInt(ts, 10, 64)
	if err != nil {
		return false
	}
	now := time.Now().Unix()
	if t < now-proofWindowSec || t > now+proofWindowSec {
		return false
	}
	g.mu.Lock()
	entry, ok := g.store.Keys[ckid]
	g.mu.Unlock()
	if !ok || entry.Key == "" || entry.Machine == "" || entry.Machine != mach {
		return false
	}
	key, err := hex.DecodeString(entry.Key)
	if err != nil || len(key) == 0 {
		return false
	}
	want := hmacPayload(key, ts, mach)
	got, err := hex.DecodeString(strings.ToLower(strings.TrimSpace(proof)))
	if err != nil || len(got) != sha256.Size {
		return false
	}
	return hmac.Equal(got, want)
}

func hmacPayload(key []byte, ts, mach string) []byte {
	m := hmac.New(sha256.New, key)
	m.Write([]byte(ts + "|" + mach))
	return m.Sum(nil)
}

func (g *ClientGuard) writeBlocked(w http.ResponseWriter) {
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.WriteHeader(http.StatusForbidden)
	ioWrite(w, `<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Restricted</title>
<style>body{font-family:system-ui,Segoe UI,sans-serif;background:#101216;color:#d7dce3;display:flex;align-items:center;justify-content:center;height:100vh;margin:0}
.card{max-width:420px;padding:34px 38px;border:1px solid #232830;border-radius:16px;background:#16191e;text-align:center}
h1{font-size:19px;margin:0 0 10px}p{font-size:13.5px;line-height:1.55;color:#98a0aa;margin:0}small{display:block;margin-top:16px;color:#676e78;font-size:11px;letter-spacing:.08em;text-transform:uppercase}</style>
</head><body><div class="card"><h1>Restricted client</h1>
<p>This console is paired to a specific client application. Open it with the designated client, or pair a new one from the client itself.</p>
<small>cockpit · client-only mode</small></div></body></html>`)
}

func ioWrite(w http.ResponseWriter, s string) { fmt.Fprint(w, s) }

// ---- API endpoints -------------------------------------------------------

// handleClientPair exchanges a one-time pairing code for a client key.
func (s *Server) handleClientPair(w http.ResponseWriter, r *http.Request) {
	g := s.clientGuard
	if g == nil || !g.enabled {
		s.writeError(w, http.StatusNotFound, "client_only_disabled", "client pairing is not enabled on this server")
		return
	}
	ip := clientIP(r)
	if ok, retry := g.pairLim.Allow(ip+"|pair", 10, 10*time.Minute); !ok {
		w.Header().Set("Retry-After", strconv.Itoa(retry))
		s.writeError(w, http.StatusTooManyRequests, "rate_limited", "too many pairing attempts — try again in "+strconv.Itoa(retry)+"s")
		return
	}
	var req struct {
		Code    string `json:"code"`
		Machine string `json:"machine"`
		Name    string `json:"name"`
	}
	if err := s.decodeJSON(w, r, &req); err != nil {
		s.writeError(w, http.StatusBadRequest, "bad_request", "invalid JSON body: "+err.Error())
		return
	}
	req.Machine = cleanString(req.Machine)
	req.Code = strings.ToUpper(cleanString(req.Code))
	if req.Machine == "" || len(req.Code) < 6 {
		s.writeError(w, http.StatusBadRequest, "bad_request", "code and machine are required")
		return
	}
	g.mu.Lock()
	defer g.mu.Unlock()
	if g.store.PairCode == "" || g.store.PairCode != req.Code {
		s.writeError(w, http.StatusForbidden, "pair_failed", "invalid or consumed pairing code")
		return
	}
	clientID := "cl_" + randHex(8)
	key := randHex(32)
	name := cleanString(req.Name)
	if name == "" {
		name = "client"
	}
	g.store.Keys[clientID] = clientKeyEntry{Key: key, Machine: req.Machine, Name: name, CreatedAt: s.now().UTC()}
	g.store.PairCode = "" // single-use
	if err := g.saveLocked(); err != nil {
		s.writeError(w, http.StatusInternalServerError, "internal_error", "internal server error")
		return
	}
	s.writeJSON(w, http.StatusOK, map[string]string{"clientId": clientID, "key": key})
}

// handleAdminPairCode generates a fresh one-time pairing code (admin only)
// and returns it — for pairing an additional client after the first.
func (s *Server) handleAdminPairCode(w http.ResponseWriter, r *http.Request) {
	g := s.clientGuard
	if g == nil || !g.enabled {
		s.writeError(w, http.StatusNotFound, "client_only_disabled", "client pairing is not enabled on this server")
		return
	}
	g.mu.Lock()
	g.store.PairCode = randClientCode()
	code := g.store.PairCode
	err := g.saveLocked()
	g.mu.Unlock()
	if err != nil {
		s.writeError(w, http.StatusInternalServerError, "internal_error", "internal server error")
		return
	}
	if s.logger != nil {
		s.logger.Printf("[cockpit] new pairing code issued by %s: %s", s.currentUser(r).Username, code)
	}
	s.writeJSON(w, http.StatusOK, map[string]string{"pairCode": code})
}

// handleListPairedClients lists paired client identities (admin only).
func (s *Server) handleListPairedClients(w http.ResponseWriter, r *http.Request) {
	g := s.clientGuard
	if g == nil || !g.enabled {
		s.writeError(w, http.StatusNotFound, "client_only_disabled", "client pairing is not enabled on this server")
		return
	}
	g.mu.Lock()
	out := []map[string]any{}
	for id, e := range g.store.Keys {
		out = append(out, map[string]any{"clientId": id, "name": e.Name, "createdAt": e.CreatedAt, "machine": e.Machine[:12]})
	}
	g.mu.Unlock()
	s.writeJSON(w, http.StatusOK, map[string]any{"clients": out})
}

// handleRevokePairedClient removes a paired client (admin only).
func (s *Server) handleRevokePairedClient(w http.ResponseWriter, r *http.Request) {
	g := s.clientGuard
	if g == nil || !g.enabled {
		s.writeError(w, http.StatusNotFound, "client_only_disabled", "client pairing is not enabled on this server")
		return
	}
	id := cleanString(r.PathValue("id"))
	g.mu.Lock()
	if _, ok := g.store.Keys[id]; !ok {
		g.mu.Unlock()
		s.writeError(w, http.StatusNotFound, "not_found", "no client with that id")
		return
	}
	delete(g.store.Keys, id)
	for tok, ss := range g.sess {
		if ss.clientID == id {
			delete(g.sess, tok)
		}
	}
	err := g.saveLocked()
	g.mu.Unlock()
	if err != nil {
		s.writeError(w, http.StatusInternalServerError, "internal_error", "internal server error")
		return
	}
	s.writeJSON(w, http.StatusOK, map[string]bool{"ok": true})
}
