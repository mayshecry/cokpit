package main

import (
	"context"
	"errors"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"cockpit/pkg/api"
	"cockpit/pkg/auth"
	"cockpit/pkg/db"
)

func main() {
	logger := log.New(os.Stdout, "[cockpit] ", log.LstdFlags|log.Lmsgprefix)

	// Configuration: env var > cockpit.json field > built-in default.
	cfg := loadConfig(envOr("COCKPIT_CONFIG", "cockpit.json"), logger)

	dbPath := cfg.Str("DB_PATH", "dbPath", "cockpit.db")
	port := cfg.Str("PORT", "port", "80")
	slaHours := cfg.Int("SLA_TARGET_HOURS", "slaTargetHours", 24, logger)
	sessionHours := cfg.Int("SESSION_HOURS", "sessionHours", 24, logger)

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	clientOnly := cfg.Bool("COCKPIT_CLIENT_ONLY", "clientOnly", false)
	trustProxy := cfg.Bool("COCKPIT_TRUST_PROXY", "trustProxy", false)
	publicURL := cfg.Str("COCKPIT_PUBLIC_URL", "publicUrl", "")
	certFile, keyFile := cfg.Str("TLS_CERT_FILE", "tlsCertFile", ""), cfg.Str("TLS_KEY_FILE", "tlsKeyFile", "")
	keysFile := cfg.Str("COCKPIT_CLIENT_KEYS", "clientKeysFile", "clientkeys.json")
	guard := api.NewClientGuard(clientOnly, keysFile, logger)
	if err := guard.Init(); err != nil {
		logger.Fatalf("client key store init: %v", err)
	}

	conn, err := db.Open(ctx, dbPath)
	if err != nil {
		logger.Fatalf("database init: %v", err)
	}
	defer conn.Close()

	store := db.New(conn)

	adminUser := cfg.Str("ADMIN_USERNAME", "adminUsername", "admin")
	adminPass := cfg.Str("ADMIN_PASSWORD", "adminPassword", "admin")
	hash, err := auth.HashPassword(adminPass)
	if err != nil {
		logger.Fatalf("hash admin password: %v", err)
	}
	if _, err := store.EnsureUser(ctx, adminUser, hash, "Administrator", auth.RoleAdmin, time.Now().UTC()); err != nil {
		logger.Fatalf("seed admin user: %v", err)
	}
	if os.Getenv("ADMIN_PASSWORD") == "" && cfg.Get("adminPassword") == "" {
		logger.Printf("WARNING: using default admin credentials %s/%s; set ADMIN_PASSWORD", adminUser, adminPass)
	}

	svr := api.New(store, api.ServerConfig{
		ClientGuard:           guard,
		TrustProxy:            trustProxy,
		PublicURL:             publicURL,
		SLATargetDefaultHours: slaHours,
		SessionHours:          sessionHours,
		Logger:                logger,
	})
	svr.EnsureBootPairCode(ctx)

	// Automatic escalation worker: raises escalations for processes that
	// breached their SLA or dwelled past a stage budget. SWI_AUTO_ESCALATE_MINUTES
	// configures the interval (0 disables the worker).
	escalateMinutes := cfg.Int("SWI_AUTO_ESCALATE_MINUTES", "swiAutoEscalateMinutes", 15, logger)
	if escalateMinutes > 0 {
		go func() {
			interval := time.Duration(escalateMinutes) * time.Minute
			ticker := time.NewTicker(interval)
			defer ticker.Stop()
			for {
				select {
				case <-ctx.Done():
					return
				case <-ticker.C:
					raised, err := store.AutoEscalate(ctx, time.Now().UTC())
					if err != nil {
						logger.Printf("auto escalate: %v", err)
						continue
					}
					for _, esc := range raised {
						logger.Printf("auto escalated order %d (%s) to %s", esc.OrderID, esc.OrderNumber, esc.Level)
					}
					if len(raised) > 0 {
						logger.Printf("auto escalate: raised %d escalation(s)", len(raised))
					}
				}
			}
		}()
		logger.Printf("auto escalation worker enabled (every %d minute(s))", escalateMinutes)
	}

	httpServer := &http.Server{
		Addr:              ":" + port,
		Handler:           svr.Handler(),
		ReadHeaderTimeout: 5 * time.Second,
		ReadTimeout:       15 * time.Second,
		WriteTimeout:      15 * time.Second,
		IdleTimeout:       60 * time.Second,
	}

	go func() {
		if certFile != "" && keyFile != "" {
			logger.Printf("listening on %s with TLS (db: %s)", httpServer.Addr, dbPath)
			if err := httpServer.ListenAndServeTLS(certFile, keyFile); err != nil && !errors.Is(err, http.ErrServerClosed) {
				logger.Fatalf("server: %v", err)
			}
			return
		}
		logger.Printf("listening on %s (db: %s)", httpServer.Addr, dbPath)
		if err := httpServer.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			logger.Fatalf("server: %v", err)
		}
	}()

	<-ctx.Done()
	logger.Printf("shutting down...")
	shutdownCtx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	if err := httpServer.Shutdown(shutdownCtx); err != nil {
		logger.Printf("shutdown: %v", err)
	}
	logger.Printf("bye")
}

func envOr(key, fallback string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return fallback
}
