# Cockpit security layers — notes

## v1 — Baseline hardening
Hardened HTTP headers (CSP, nosniff, frame deny, Referrer-Policy, Permissions-Policy),
same-origin mutation guard, login throttling (5/5min per IP+user, 20/min per IP,
reset on success), password policy (≥10 chars, letter + digit/symbol).

## v2 — Client-only mode
`pkg/api/clientguard.go` + pairing page + `client/` launcher. UI gated to paired devices:
HMAC-SHA256 proof (ts|machine) exchanged for an HttpOnly SameSite=Strict cookie.
API stays open (Bearer tokens). One-time pairing codes per device.

## v3 — Pairing code overhaul
8-digit numeric codes (`1234-5678`), crypto-random per digit; normalized entry
(case/dash/spaces-insensitive); re-printed every boot; fixed input truncation bug
and admin client-list panic.

## v4 — Phone QR pairing + completion fix
Pair response now echoes machine/name (fixes "file created but never set through").
Phone flow: admin QR (Users → Pair a device) → /launch.html?code=… → auto-pair →
login form. New: GET /api/v1/admin/pair-qr, POST /api/v1/launch.

## v5 — QR sign-in
Pair+login once; afterwards rotate-to-scan logins. Login screens show a rotating
150s ticket QR; paired+logged-in phone approves → waiting screen gets the session
token. Single-delivery tickets, bearer-auth approval.
Endpoints: GET /api/v1/qr-login, /qr-login/status, POST /api/v1/qr-login/approve.

## v6 — Domain + HTTPS deployment
- `COCKPIT_PUBLIC_URL`: external URL drives all QR rendering + cookie Secure flag.
- `COCKPIT_TRUST_PROXY=1`: honor X-Forwarded-For/-Proto/-Host behind nginx/Caddy/IIS.
  Default OFF: forwarded headers are ignored (limiter spoofing impossible on direct nets).
- `TLS_CERT_FILE` + `TLS_KEY_FILE`: native TLS termination in the binary.
- Session cookie gets Secure whenever the external scheme is https.
- Client server resolution: COCKPIT_SERVER env > `server` key in cockpit-client.json
  > http://localhost.


## v7 — cockpit.json config file

All server settings now also read from `cockpit.json` next to the exe (path via
`COCKPIT_CONFIG`). Resolution: env var > file > default. Unknown keys abort
startup with a helpful list (typo protection). See cockpit.example.json for the
full schema. The client side keeps its own cockpit-client.json / COCKPIT_SERVER.

## v8 — QR sign-in phone-reliability fixes
- ckdpair cookie now SameSite=Lax both sites: opening a QR from the phone's
  camera/scanner app is a cross-app navigation — Strict dropped the cookie,
  so scanned phones landed on the 403 block page. Lax sends it for top-level
  navigations; all mutations stay same-origin POST + originGuard protected.
- /qr-approve.html + /js/qrapprove.js are on the open allowlist — approval is
  guarded by the phone's bearer token, so paired-phone-required was redundant
  breakage for scanner-app contexts.
- Login QR card now prints the exact URL it encodes under the QR + a loud
  warning when it points at localhost (phones can't reach it — set publicUrl).
- Unkept phone fallback on the approve page now links to /launch.html (pair)
  instead of the guarded root.


## v9 — Account-linked pairing
- Pairing codes can be bound to an ACCOUNT: POST /admin/pair-code {"username":"…"}
  (or GET /admin/pair-qr?username=…). A device pairing with that code receives the
  account's login session in the same response — scan once, sign in done.
- Users page: per-user "📱 Pair phone" action opens a QR dialog for that account;
  the generic device card is explicitly desktop/no-account now.
- /admin/client-keys entries now carry the bound username; /pair responses stay
  device-only when issued without a username (backward compatible).

## v10 — Phone flows without WebCrypto + self-healing QR chain
- POST /api/v1/pair now issues the device session cookie (ckdpair, 12h, Lax,
  Secure on https) in the SAME round trip as the pairing. Phones on plain-http
  LAN origins (http://192.168.x.x) have NO crypto.subtle — they could not sign
  the /launch HMAC proof, so pairing previously "worked" but the phone stayed
  gated. One-time code is itself the proof; cookie ships with it.
- launch.js carries a bundled pure-JS SHA-256 + HMAC-SHA-256 fallback
  (RFC 4231 vectors verified) so cookie RENEWAL via /launch keeps working on
  no-WebCrypto origins too.
- qr-approve with NO cockpit login no longer dead-ends: it forwards
  ?ticket=… into the launch flow — phone pairs (code typed once; account-linked
  code signs it in) and then approves THAT same ticket automatically, in one
  continuous chain. The login QR is now truly "scan once on a brand-new phone".

## v11 — Pairing codes moved into the database (the real account-link fix)
- Pair codes are rows in a new `pair_codes` table (code, username binding,
  created-by, created/expires, used): MANY codes are active at once. The old
  design kept exactly ONE code+link in clientkeys.json, so any second code
  request ("Pair phone" for another user, a desktop code, the boot fallback)
  silently destroyed the first QR — including its account link. That was the
  "auto sign in doesn't work / can't link the account" breakage.
- Codes are single-use with a 30-minute TTL; re-requesting a code for the
  same account REUSES the still-live one, so re-rendered QRs keep working.
- CanonicalCode normalization (dash/space/case-insensitive) matches at the DB
  layer — "4455 7788" and "4455-7788" are the same code.
- Upgrade path: a leftover code+binding from clientkeys.json (v9/v10 installs)
  is auto-imported into the database on first boot (valid 24h) — existing
  printed QRs keep working.
- Boot still prints a rescue pairing code every boot (now DB-backed,
  survives restarts).

## v12 — Mobile shell repair (phones were genuinely broken to navigate)
- The topbar squeezed the nav strip to a ~15px sliver on phones (all 11 nav
  links squashed between brand and toolbar), pushed the whole page 19px past
  the viewport (left-edge content clipped) and the hover-reveal-label trick
  did nothing on touch. Mobile now gets a two-row bar: brand + essential
  controls on row 1, a full-width scrollable nav strip with ALL labels on
  row 2; keyboard-shortcut button hidden on touch.
- The wrapped bar is pinned non-shrinking (flex 0 0 auto) and the app column
  becomes a flex column, so the scroll region gets exactly what remains — no
  more bottom clipping, no phantom 35px header.
- Card section heads (Users, Config, SI…) wrap on phones instead of crushing
  their description text into a one-word-per-line sliver column.
- Orders controls stack sanely (chips full width, Mine tucked right, search
  spans the row); page-head action buttons wrap.
- Order detail on phones: true full-cover sheet "a bit more up" — released
  .main's stacking context so the scrim frosts the whole screen incl. topbar,
  and the sheet top-aligns + caps its height instead of center-clipping its
  header (ORDER #nn was painted above the viewport).
- Verified at 360/390/640/1100/1440: zero horizontal overflow, zero console
  errors, desktop layout unchanged.
