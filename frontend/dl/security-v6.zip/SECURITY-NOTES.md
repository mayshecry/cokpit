# Cockpit security layers — notes

## v1 — Baseline hardening
Hardened HTTP headers (CSP, nosniff, frame deny, Referrer-Policy, Permissions-Policy),
same-origin mutation guard, login throttling (5/5min per IP+user, 20/min per IP,
reset on success), password policy (≥10 chars, letter + digit/symbol).

## v2 — Client-only mode
`pkg/api/clientguard.go` + pairing page + `client/` launcher. UI gated to paired devices:
HMAC-SHA256 proof (ts|machine) exchanged for an HttpOnly SameSite=Strict cookie.
API stays open (Bearer tokens). One-time pairing codes per device.

## v3 — Pairing code overhaul
8-digit numeric codes (`1234-5678`), crypto-random per digit; normalized entry
(case/dash/spaces-insensitive); re-printed every boot; fixed input truncation bug
and admin client-list panic.

## v4 — Phone QR pairing + completion fix
Pair response now echoes machine/name (fixes "file created but never set through").
Phone flow: admin QR (Users → Pair a device) → /launch.html?code=… → auto-pair →
login form. New: GET /api/v1/admin/pair-qr, POST /api/v1/launch.

## v5 — QR sign-in
Pair+login once; afterwards rotate-to-scan logins. Login screens show a rotating
150s ticket QR; paired+logged-in phone approves → waiting screen gets the session
token. Single-delivery tickets, bearer-auth approval.
Endpoints: GET /api/v1/qr-login, /qr-login/status, POST /api/v1/qr-login/approve.

## v6 — Domain + HTTPS deployment
- `COCKPIT_PUBLIC_URL`: external URL drives all QR rendering + cookie Secure flag.
- `COCKPIT_TRUST_PROXY=1`: honor X-Forwarded-For/-Proto/-Host behind nginx/Caddy/IIS.
  Default OFF: forwarded headers are ignored (limiter spoofing impossible on direct nets).
- `TLS_CERT_FILE` + `TLS_KEY_FILE`: native TLS termination in the binary.
- Session cookie gets Secure whenever the external scheme is https.
- Client server resolution: COCKPIT_SERVER env > `server` key in cockpit-client.json
  > http://localhost.
