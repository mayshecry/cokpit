# Cockpit security-v1 applier
# Replaces the app source in your local repo with this snapshot and rebuilds.
# Your cockpit.db database is NEVER touched.
param(
  [string]$RepoRoot = (Get-Location).Path,
  [string]$OutExe     = 'cockpit.exe'
)
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$src  = $here   # snapshot root sits next to apply.ps1
Set-Location $RepoRoot

if (-not (Test-Path (Join-Path $RepoRoot 'go.mod'))) { throw "go.mod not found in $RepoRoot — run me from (or pass) the cockpit repo root." }
if (-not (Get-Command go -ErrorAction SilentlyContinue)) { throw "Go is not installed or not on PATH. Install from https://go.dev/dl/ first." }

$ts = Get-Date -Format 'yyyyMMdd-HHmmss'
$backupDir = Join-Path $RepoRoot "backup-security-v3-$ts"
New-Item -ItemType Directory -Path $backupDir | Out-Null

$toReplace = @('main.go','go.mod','go.sum','README.md','docs','pkg','frontend','client','test.sh')
foreach ($item in $toReplace) {
  $dst = Join-Path $RepoRoot $item
  if (Test-Path $dst) {
    Copy-Item $dst (Join-Path $backupDir $item) -Recurse -Force
    if (Test-Path $dst -PathType Container) { Remove-Item $dst -Recurse -Force } else { Remove-Item $dst -Force }
  }
  Copy-Item (Join-Path $src $item) $dst -Recurse -Force
}

Write-Host "Building..." -ForegroundColor Cyan
& go build -mod=mod -o $OutExe .
if ($LASTEXITCODE -ne 0) { throw "go build failed — sources kept at backup: $backupDir" }

Write-Host ""
Write-Host "OK — security patch applied and rebuilt to $RepoRoot\$OutExe" -ForegroundColor Green
Write-Host "Backup of the previous state: $backupDir"
Write-Host "Restart the app: stop the old process, then start it again: .\$OutExe"
Write-Host "Useful env vars: `$env:PORT='8080'   `$env:COCKPIT_CLIENT_ONLY='1'  (1 = UI only for paired Esprit ICT clients)"
Write-Host ""
Write-Host "Client launcher (client-only mode): cd \"$RepoRoot\client\"; go mod tidy; go build -ldflags='-H windowsgui' -o CockpitClient.exe ."
Write-Host "First run with COCKPIT_CLIENT_ONLY=1 prints a one-time PAIRING CODE in the console — enter it once in the client."
