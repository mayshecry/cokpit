# Security patch v1 — what changed

## Runtime hardening (pkg/api/security.go, server.go)
- **Security headers on every response**: strict Content-Security-Policy
  (scripts: self + cdnjs; styles: self + inline; no framing), nosniff,
  X-Frame-Options: DENY, Referrer-Policy: same-origin, restrictive
  Permissions-Policy, Cross-Origin-Resource-Policy, and HSTS once TLS is on.
- **Cross-origin mutation guard**: POST/PUT/PATCH/DELETE requests that send
  an Origin header for a different host get 403.

## Login protection (auth_handlers.go, security.go)
- **Fixed-window brute-force limiter** (in-memory, zero new dependencies):
  - per account + IP: 5 attempts / 5 minutes
  - per IP overall: 20 attempts / minute
  - responds HTTP 429 with Retry-After
  - counter resets on successful login, so legitimate users never lock out.

## Password policy (users_handlers.go, security.go)
- New users: minimum 10 chars, must contain letters and at least one
  digit or symbol, and must not equal the username.

Verified end-to-end with the UI regression battery.


## v2 — Client-only mode (new)

`pkg/api/clientguard.go` + pairing page (`pair-guide.html`, `js/pairguide.js`) + `client/` launcher.

Enable with `$env:COCKPIT_CLIENT_ONLY='1'` before starting `cockpit.exe`. On first boot with the flag
set, the console prints `PAIRING CODE: XXXX-XXX`. Open `CockpitClient.exe`, enter the code once —
the device is paired (`cockpit-client.json` next to the exe). All further launches are silent.

- UI gated: only paired clients (or requests carrying the session cookie) get HTML/JS/CSS and /dl/.
- API untouched: `/api/v1/**` keeps using Bearer tokens — integrations keep working.
- Unpaired allowlist: `/healthz`, `/scan.html`, pairing page assets.
- Admin API: `POST /api/v1/admin/pair-code` (fresh code), `GET /api/v1/admin/client-keys`,
  `POST /api/v1/admin/client-keys/{id}/revoke`.
- Key store: `clientkeys.json` next to the db (0600) — excluded from backups backups are
  automatic: existing store survives, the apply script doesn't touch it.
- Honesty note: the client-side key is extractable with effort (any binary secret is); it is
  machine-bound, so a copied file fails elsewhere. Treat as a strong practical barrier, not crypto.


## v3 — Pairing code overhaul (bugfix)

- Codes are now 8-digit numeric `1234-5678`, crypto-random per digit (old generator reused random bytes and had modulo bias).
- Code entry is normalized: case-insensitive, dash/spaces optional — `1234-5678`, `1234 5678`, `12345678` all work. Legacy alphanumeric codes in existing key stores keep working.
- THE fix: the pair page input previously truncated to 7 chars while the server generated 8 — typed codes could never match. Fixed (8 chars, 4-4 grouping, full alnum alphabet).
- Server re-prints the active pairing code on EVERY boot; when none is active it prints how to issue one.
- Fixed panic on GET /admin/client-keys when a machine id was shorter than 12 chars.
