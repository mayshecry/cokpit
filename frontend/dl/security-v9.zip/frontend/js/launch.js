'use strict';
// Phone launch/linking page for client-only mode.
// - ?code=1234-5678 in the URL (from the admin QR) → pair automatically.
// - Already paired → signs a launch proof (HMAC over localStorage-held key)
//   and exchanges it for the session cookie via POST /api/v1/launch.
// - After the cookie is set, the user lands on "/" → normal login form.
(function () {
  const $ = (id) => document.getElementById(id);
  const codeEl = $('code'), goEl = $('go'), msgEl = $('msg'), leadEl = $('lead'), formEl = $('form');
  const LS_PAIR = 'ck-pair', LS_MACHINE = 'ck-machine';

  const fail = (t) => { msgEl.className = 'err'; msgEl.textContent = t; };
  const ok = (t) => { msgEl.className = 'err ok'; msgEl.textContent = t; };
  const start = (t) => { msgEl.className = 'err'; msgEl.innerHTML = '<span class="spin"></span> ' + t; };

  const hex = (buf) => Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');

  function machine() {
    let m = localStorage.getItem(LS_MACHINE);
    if (!m) {
      const b = new Uint8Array(16); crypto.getRandomValues(b);
      m = hex(b);
      localStorage.setItem(LS_MACHINE, m);
    }
    return m;
  }

  let pairedUser = null;

  const loadPair = () => {
    try { return JSON.parse(localStorage.getItem(LS_PAIR) || 'null'); } catch { return null; }
  };
  const savePair = (p) => localStorage.setItem(LS_PAIR, JSON.stringify(p));

  async function pair(code) {
    const r = await fetch('/api/v1/pair', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code, machine: machine(), name: 'phone' }),
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error((j.error && j.error.message) || 'Pairing failed.');
    // The machine we sent is the pairing target — store it verbatim.
    savePair({ clientId: j.clientId, key: j.key, machine: machine(), savedAt: new Date().toISOString() });
    // Account-linked code → the server included a login session: the phone is
    // paired AND signed in as that account in one go.
    if (j.token && j.user) {
      localStorage.setItem('cockpit_token', j.token);
      localStorage.setItem('cockpit_user', JSON.stringify(j.user));
      pairedUser = j.user;
    }
  }

  async function launch(p) {
    const ts = String(Math.floor(Date.now() / 1000));
    const kb = new Uint8Array(p.key.match(/.{2}/g).map(h => parseInt(h, 16)));
    const k = await crypto.subtle.importKey('raw', kb, { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
    const sig = await crypto.subtle.sign('HMAC', k, new TextEncoder().encode(ts + '|' + p.machine));
    const r = await fetch('/api/v1/launch', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ckid: p.clientId, ts, mach: p.machine, proof: hex(sig) }),
    });
    if (r.status !== 204) {
      if (r.status === 403) { localStorage.removeItem(LS_PAIR); }
      const j = await r.json().catch(() => ({}));
      throw new Error((j.error && j.error.message) || 'Launch failed.');
    }
  }

  async function run() {
    const urlCode = new URLSearchParams(location.search).get('code');
    try {
      if (urlCode) {
        start('Linking this device…');
        await pair(urlCode.trim());
      }
      const p = loadPair();
      if (p && p.clientId && p.key && p.machine) {
        start(urlCode ? 'Linked! Signing you in…' : 'Signing you in…');
        await launch(p);
        ok(pairedUser ? ('Linked & signed in as ' + (pairedUser.username || 'you') + '…') : 'Device linked — opening login…');
        location.replace('/');
        return;
      }
      // no pairing and no code → show the manual entry form
      leadEl.textContent = 'Scan the QR code your admin shows in Users → Pair a device, or enter the pairing code.';
      formEl.hidden = false;
      codeEl.focus();
    } catch (e) {
      fail(e.message || String(e));
      leadEl.textContent = 'Could not complete device linking. You can enter the code manually:';
      formEl.hidden = false;
      codeEl.value = urlCode ? urlCode.trim().toUpperCase() : '';
    }
  }

  goEl.addEventListener('click', async () => {
    const c = codeEl.value.trim().toUpperCase();
    if (c.replace(/[^A-Z0-9]/g, '').length < 6) { fail('Enter the pairing code exactly as issued (1234-5678).'); return; }
    goEl.disabled = true; fail(''); start('Linking…');
    try {
      await pair(c);
      const p = loadPair();
      start('Linked! Signing you in…');
      await launch(p);
      location.assign('/');
    } catch (e) { fail(e.message || String(e)); goEl.disabled = false; }
  });

  codeEl.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); goEl.click(); } });
  codeEl.addEventListener('input', () => {
    const raw = codeEl.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8);
    codeEl.value = raw.length > 4 ? raw.slice(0, 4) + '-' + raw.slice(4) : raw;
  });

  run();
})();
