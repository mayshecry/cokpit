package main

import (
	"encoding/json"
	"fmt"
	"log"
	"os"
	"strconv"
	"strings"
)

// Config file support: a single cockpit.json next to the exe (path overridable
// with COCKPIT_CONFIG). Resolution order per setting:
//
//	env var  >  cockpit.json field  >  built-in default
//
// Missing file is fine (env-only setups keep working unchanged); a PRESENT but
// invalid file is a hard fail — silent fallback would hide typos.

type fileConfig struct {
	raw map[string]json.RawMessage
}

func loadConfig(path string, logger *log.Logger) *fileConfig {
	c := &fileConfig{raw: map[string]json.RawMessage{}}
	raw, err := os.ReadFile(path)
	if err != nil {
		if !os.IsNotExist(err) && logger != nil {
			logger.Printf("config: cannot read %s (%v) — using env/defaults", path, err)
		}
		return c
	}
	var m map[string]json.RawMessage
	// Pass 1: validate keys against the known set (typo protection).
	var known struct {
		Port                   any `json:"port"`
		DBPath                 any `json:"dbPath"`
		SLATargetHours         any `json:"slaTargetHours"`
		SessionHours           any `json:"sessionHours"`
		AdminUsername          any `json:"adminUsername"`
		AdminPassword          any `json:"adminPassword"`
		SWIAutoEscalateMinutes any `json:"swiAutoEscalateMinutes"`
		ClientOnly             any `json:"clientOnly"`
		ClientKeysFile         any `json:"clientKeysFile"`
		PublicURL              any `json:"publicUrl"`
		TrustProxy             any `json:"trustProxy"`
		TLSCertFile            any `json:"tlsCertFile"`
		TLSKeyFile             any `json:"tlsKeyFile"`
	}
	dec0 := json.NewDecoder(strings.NewReader(string(raw)))
	dec0.DisallowUnknownFields()
	if err := dec0.Decode(&known); err != nil {
		fmt.Fprintf(os.Stderr, "[cockpit] FATAL: %s: %v\n", path, err)
		fmt.Fprintln(os.Stderr, "[cockpit] valid keys: port, dbPath, slaTargetHours, sessionHours, adminUsername, adminPassword, swiAutoEscalateMinutes, clientOnly, clientKeysFile, publicUrl, trustProxy, tlsCertFile, tlsKeyFile")
		os.Exit(1)
	}
	// Pass 2: values.
	dec := json.NewDecoder(strings.NewReader(string(raw)))
	if err := dec.Decode(&m); err != nil {
		fmt.Fprintf(os.Stderr, "[cockpit] FATAL: %s: %v\n", path, err)
		fmt.Fprintln(os.Stderr, "[cockpit] valid keys: port, dbPath, slaTargetHours, sessionHours, adminUsername, adminPassword, swiAutoEscalateMinutes, clientOnly, clientKeysFile, publicUrl, trustProxy, tlsCertFile, tlsKeyFile")
		os.Exit(1)
	}
	c.raw = m
	if logger != nil {
		logger.Printf("config: loaded %s (%d settings)", path, len(m))
	}
	return c
}

// Get returns the field's display value if present ("1" for true) — used for
// "is set?" probes where the exact value doesn't matter.
func (c *fileConfig) Get(key string) string {
	raw, ok := c.raw[key]
	if !ok {
		return ""
	}
	var s string
	if json.Unmarshal(raw, &s) == nil {
		return s
	}
	var b bool
	if json.Unmarshal(raw, &b) == nil {
		if b {
			return "1"
		}
		return ""
	}
	var n float64
	if json.Unmarshal(raw, &n) == nil {
		return strconv.FormatFloat(n, 'f', -1, 64)
	}
	return ""
}

// Str resolves env > file > default. File values may be strings OR (for
// convenience) numbers/bools, which are stringified.
func (c *fileConfig) Str(envKey, fileKey, def string) string {
	if v := os.Getenv(envKey); v != "" {
		return v
	}
	if v := c.Get(fileKey); v != "" {
		return v
	}
	return def
}

// Int resolves env > file > default, warning (and falling back) on bad values.
func (c *fileConfig) Int(envKey, fileKey string, def int, logger *log.Logger) int {
	v, src := "", ""
	if e := os.Getenv(envKey); e != "" {
		v, src = e, envKey
	} else if f := c.Get(fileKey); f != "" {
		v, src = f, fileKey
	} else {
		return def
	}
	n, err := strconv.Atoi(v)
	if err != nil || n < 0 {
		if logger != nil {
			logger.Printf("config: invalid %s value %q, using %d", src, v, def)
		}
		return def
	}
	return n
}

// Bool resolves env > file > default. Accepts true/"true"/"1".
func (c *fileConfig) Bool(envKey, fileKey string, def bool) bool {
	if v := os.Getenv(envKey); v != "" {
		return v == "1" || strings.EqualFold(v, "true")
	}
	raw, ok := c.raw[fileKey]
	if !ok {
		return def
	}
	var b bool
	if json.Unmarshal(raw, &b) == nil {
		return b
	}
	var s string
	if json.Unmarshal(raw, &s) == nil {
		return s == "1" || strings.EqualFold(s, "true")
	}
	return def
}
