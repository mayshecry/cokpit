'use strict';

/* Quality menu — QC cockpit for one month: precision KPIs with month-over-month
   deltas and six-month sparklines, daily pass/fail trend with rolling rate line
   and hover tooltip, animated donut, rework-per-tech table, fail-reason
   breakdown and a latest-checks feed. Month switches slide; numbers morph. */

const Quality = {
  month: null,
  data: null,

  curMonth() {
    const d = new Date();
    return d.toISOString().slice(0, 7);
  },

  liveRefresh() {
    const now = Date.now();
    if (Quality._lastLive && now - Quality._lastLive < 1500) return;
    if (!Quality.data) return; // not initialised — normal load handles it
    Quality._lastLive = now;
    Quality.load(0);
  },

  async load(dir) {
    if (!Quality.month) Quality.month = Quality.curMonth();
    $('#qc-month').textContent = Quality.month;
    const box = $('#quality-content');
    if (!Quality.data) Quality.skeleton(box);
    let wrap = box.querySelector('.qc-wrap');
    if (dir && wrap) {
      wrap.classList.add(dir > 0 ? 'leave-next' : 'leave-prev');
      await new Promise((r) => setTimeout(r, 170));
    }
    try {
      const d = await api('GET', '/api/v1/stats/qc?month=' + Quality.month);
      Quality.data = d;
      Quality.render(d, dir || 0);
    } catch (err) {
      box.innerHTML = `<p class="muted">Quality stats unavailable: ${esc(err.message)}</p>`;
    }
  },

  skeleton(box) {
    box.innerHTML = `
      <div class="qc-skel" aria-hidden="true">
        <div class="dash-kpis qc-kpis">${'<div class="kpi"><span class="sk sk-lg"></span><span class="sk sk-sm"></span></div>'.repeat(5)}</div>
        <div class="dash-grid qc-grid">
          <div class="card dash-card qc-span2"><span class="sk sk-chart"></span></div>
          <div class="card dash-card"><span class="sk sk-chart"></span></div>
          <div class="card dash-card qc-span2"><span class="sk sk-chart"></span></div>
          <div class="card dash-card"><span class="sk sk-chart"></span></div>
        </div>
      </div>`;
  },

  shift(delta) {
    const [y, m] = Quality.month.split('-').map(Number);
    const d = new Date(Date.UTC(y, m - 1 + delta, 1));
    const next = d.toISOString().slice(0, 7);
    if (delta > 0 && next > Quality.curMonth()) return;
    if (next === Quality.month) return;
    Quality.month = next;
    Quality.load(delta);
  },

  monthName(shift) {
    const [y, m] = Quality.month.split('-').map(Number);
    const d = new Date(Date.UTC(y, m - 1 + (shift || 0), 1));
    return d.toLocaleDateString('en-GB', { month: 'short', year: 'numeric', timeZone: 'UTC' }).toLowerCase();
  },

  pct(x) {
    return x == null ? '—' : x.toFixed(2) + '%';
  },

  deltaHtml(cur, prev, unit, invert) {
    if (cur == null || prev == null || prev === undefined) return '<span class="qc-delta na">no history</span>';
    const d = cur - prev;
    if (Math.abs(d) < 0.005) return '<span class="qc-delta flat" title="versus previous month">→ 0.00' + (unit || ' pp') + '</span>';
    const good = invert ? d < 0 : d > 0;
    const arrow = d > 0 ? '▲' : '▼';
    return `<span class="qc-delta ${good ? 'good' : 'bad'}" title="versus previous month">${arrow} ${Math.abs(d).toFixed(2)}${unit || ' pp'}</span>`;
  },

  sparkSvg(vals, opts) {
    const o = opts || {};
    const w = o.w || 84, h = o.h || 26, pad = 3;
    const pts = [];
    let min = Infinity, max = -Infinity;
    vals.forEach((v) => { if (v != null) { min = Math.min(min, v); max = Math.max(max, v); } });
    if (min === Infinity) return '';
    if (max - min < 0.001) { max += 1; min -= 1; }
    vals.forEach((v, i) => {
      if (v == null) { pts.push(null); return; }
      const x = pad + (i / (vals.length - 1)) * (w - pad * 2);
      const y = pad + (1 - (v - min) / (max - min)) * (h - pad * 2);
      pts.push([x, y]);
    });
    let d = '', pen = false;
    pts.forEach((p) => {
      if (!p) { pen = false; return; }
      d += (pen ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1) + ' ';
      pen = true;
    });
    const last = pts.filter(Boolean).pop();
    return `<svg viewBox="0 0 ${w} ${h}" class="qc-spark ${o.cls || ''}" width="${w}" height="${h}" aria-hidden="true">
      <path d="${d}" fill="none"></path>
      <circle cx="${last[0].toFixed(1)}" cy="${last[1].toFixed(1)}" r="2.4"></circle>
    </svg>`;
  },

  trendSvg(trend) {
    if (!trend || !trend.length) return '';
    const W = 660, H = 200, PL = 30, PR = 34, PB = 26, PT = 12;
    const iw = W - PL - PR, ih = H - PT - PB;
    const max = Math.max(...trend.map((t) => t.pass + t.fail), 1);
    const bw = iw / trend.length;
    let bars = '';
    const pts = [];
    const rolls = [];
    let run = { p: 0, f: 0, n: 0 };
    trend.forEach((t, i) => {
      run.p += t.pass; run.f += t.fail; run.n++;
      if (run.n > 7) { const o = trend[i - 7]; run.p -= o.pass; run.f -= o.fail; run.n--; }
      const tot = run.p + run.f;
      const roll = tot ? (run.p / tot) * 100 : 100;
      rolls.push(roll);
      const x = PL + i * bw;
      const hp = (t.pass / max) * ih;
      const hf = (t.fail / max) * ih;
      const w = Math.min(Math.max(2, bw * 0.62), 26);
      const ox = x + (bw - w) / 2;
      const tip = `data-d="${t.day}" data-p="${t.pass}" data-f="${t.fail}" data-r="${roll.toFixed(2)}"`;
      bars += `<rect class="qc-bar-p" ${tip} x="${ox.toFixed(1)}" y="${(PT + ih - hp).toFixed(1)}" width="${w.toFixed(1)}" height="${hp.toFixed(1)}" rx="2.5" style="animation-delay:${i * 16}ms"></rect>`;
      if (hf > 0.5) bars += `<rect class="qc-bar-f" ${tip} x="${ox.toFixed(1)}" y="${(PT + ih - hp - hf).toFixed(1)}" width="${w.toFixed(1)}" height="${hf.toFixed(1)}" rx="2.5" style="animation-delay:${i * 16 + 60}ms"></rect>`;
      pts.push([(x + bw / 2).toFixed(1), (PT + ih - (roll / 100) * ih).toFixed(1)]);
    });
    const path = pts.map((p, i) => (i ? 'L' : 'M') + p[0] + ' ' + p[1]).join(' ');
    const ticks = [0, 0.5, 1].map((f) => {
      const y = PT + ih - f * ih;
      return `<line class="qc-grid-l" x1="${PL}" y1="${y}" x2="${W - PR}" y2="${y}"></line>
        <text class="qc-ax" x="${PL - 7}" y="${y + 3.5}" text-anchor="end">${Math.round(f * max)}</text>
        <text class="qc-ax r" x="${W - PR + 7}" y="${y + 3.5}">${Math.round(f * 100)}%</text>`;
    }).join('');
    const every = Math.ceil(trend.length / 8);
    const labels = trend.map((t, i) => (i % every === 0 ? `<text class="qc-ax" x="${PL + i * bw + bw / 2}" y="${H - 8}" text-anchor="middle">${t.day.slice(8)}</text>` : '')).join('');
    const area = `${path} L ${pts[pts.length - 1][0]} ${PT + ih} L ${pts[0][0]} ${PT + ih} Z`;
    const last = pts[pts.length - 1];
    return `<svg viewBox="0 0 ${W} ${H}" class="qc-trend" role="img" aria-label="Daily QC checks with rolling pass rate">
      <defs>
        <linearGradient id="qcGPass" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stop-color="var(--good)" stop-opacity="1"/><stop offset="1" stop-color="var(--good)" stop-opacity=".68"/>
        </linearGradient>
        <linearGradient id="qcGFail" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stop-color="var(--warn)" stop-opacity=".95"/><stop offset="1" stop-color="var(--bad)" stop-opacity=".85"/>
        </linearGradient>
        <linearGradient id="qcGArea" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stop-color="var(--info)" stop-opacity=".16"/><stop offset="1" stop-color="var(--info)" stop-opacity="0"/>
        </linearGradient>
      </defs>
      ${ticks}${bars}
      <path class="qc-area" d="${area}" fill="url(#qcGArea)"></path>
      <path class="qc-line" d="${path}" fill="none"></path>
      <circle class="qc-line-end" cx="${last[0]}" cy="${last[1]}" r="3"></circle>
      ${labels}
    </svg>`;
  },

  bindDonut(box, m) {
    const wrap = box.querySelector('.qc-donut-wrap');
    if (!wrap) return;
    const v = wrap.querySelector('.dc-v');
    const l = wrap.querySelector('.dc-l');
    const d = wrap.querySelector('.dc-d');
    const base = { v: '', l: l.textContent, d: d ? d.textContent : '', vis: d ? d.style.visibility : '' };
    const show = (nv, nl, color) => {
      v.textContent = nv; l.textContent = nl;
      v.style.color = color || '';
      if (d) d.style.visibility = 'hidden';
    };
    wrap.addEventListener('mouseover', (e) => {
      const li = e.target.closest('[data-seg]');
      if (!li) return;
      const seg = li.dataset.seg;
      wrap.setAttribute('data-hl', seg);
      if (seg === 'pass') show(String(m.pass), 'passed' + (m.pass + m.fail ? ' · ' + Math.round((m.pass / (m.pass + m.fail)) * 100) + '%' : ''), 'var(--good)');
      else if (seg === 'fail') show(String(m.fail), 'failed' + (m.pass + m.fail ? ' · ' + Math.round((m.fail / (m.pass + m.fail)) * 100) + '%' : ''), 'var(--bad)');
      else show(m.prevRate == null ? '—' : m.prevRate.toFixed(2) + '%', Quality.monthName(-1), '');
    });
    wrap.addEventListener('mouseleave', () => {
      wrap.removeAttribute('data-hl');
      v.textContent = m.rate.toFixed(2) + '%';
      l.textContent = base.l;
      v.style.color = '';
      if (d) d.style.visibility = '';
    });
  },

  donutSvg(pass, fail, rate) {
    const R = 52, C = 2 * Math.PI * R;
    const tot = pass + fail;
    const passLen = tot ? (pass / tot) * C : 0;
    const failLen = tot ? (fail / tot) * C : 0;
    const gap = pass > 0 && fail > 0 ? 4 : 0;
    const pLen = pass > 0 ? Math.max(2.5, passLen - gap) : 0;
    const fLen = fail > 0 ? Math.max(2.5, failLen - gap) : 0;
    const badAngle = -90 + (passLen / C) * 360;
    return `
      <svg viewBox="0 0 150 150" class="donut qc-donut" role="img" aria-label="Pass versus fail share">
        <defs>
          <linearGradient id="qcDgBad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="var(--warn)"/><stop offset="1" stop-color="var(--bad)"/>
          </linearGradient>
          <linearGradient id="qcDgGood" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="var(--good)"/><stop offset="1" stop-color="var(--info)"/>
          </linearGradient>
        </defs>
        <circle r="63.5" cx="75" cy="75" fill="none" stroke="var(--border)" stroke-width="1" stroke-dasharray="1 5" opacity=".8"></circle>
        <circle r="52" cx="75" cy="75" fill="none" stroke="var(--neutral-soft)" stroke-width="15"></circle>
        ${fail > 0 ? `<circle class="seg seg-fail" r="52" cx="75" cy="75" fill="none" stroke="url(#qcDgBad)" stroke-width="15" stroke-linecap="round"
          stroke-dasharray="${fLen.toFixed(1)} ${C.toFixed(1)}" transform="rotate(${badAngle.toFixed(2)} 75 75)"></circle>` : ''}
        ${pass > 0 ? `<circle class="seg qc-donut-arc" r="52" cx="75" cy="75" fill="none" stroke="url(#qcDgGood)" stroke-width="15" stroke-linecap="round"
          stroke-dasharray="${pLen.toFixed(1)} ${C.toFixed(1)}" transform="rotate(-90 75 75)"></circle>` : ''}
      </svg>`;
  },

  render(d, dir) {
    const rows = d.perUser || [];
    const pass = d.pass || 0;
    const fail = d.fail || 0;
    const tot = d.checks || 0;
    const rate = d.rate || 0;
    const prevRate = d.prevRate == null ? null : d.prevRate;
    const worst = rows.length && rows[0].fail > 0 ? rows[0].username : null;
    const name = (u) => (d.userNames || {})[u] || u;
    const trend = d.trend || [];
    const reasons = d.reasons || [];
    const recent = d.recent || [];
    const history = d.history || [];
    const maxReason = reasons.length ? reasons[0].count : 1;
    const maxFail = Math.max(...rows.map((r) => r.fail), 1);
    const histRates = history.map((h) => h.rate);

    const kpis = `
      <div class="dash-kpis qc-kpis">
        <div class="kpi"><span class="kpi-v" data-count="${tot}">0</span><span class="kpi-l">QC checks</span></div>
        <div class="kpi ${rate >= 95 ? 'good' : rate >= 90 ? '' : 'bad'}"><span class="kpi-v" data-count="${rate.toFixed(2)}" data-dec="2" data-suffix="%">0%</span><span class="kpi-l">first-pass yield</span>${Quality.sparkSvg(histRates, { cls: 'sp-good' })}</div>
        <div class="kpi ${fail ? 'bad' : 'good'}"><span class="kpi-v" data-count="${fail}">0</span><span class="kpi-l">rework items</span></div>
        <div class="kpi"><span class="kpi-v" data-count="${rows.length}">0</span><span class="kpi-l">techs checked</span></div>
        <div class="kpi qc-delta-tile">${prevRate == null ? '<span class="kpi-v dim">—</span>' : `<span class="kpi-v ${rate - prevRate >= 0 ? 'good-v' : 'bad-v'}">${(rate - prevRate >= 0 ? '+' : '−') + Math.abs(rate - prevRate).toFixed(2)}</span>`}<span class="kpi-l">pp vs ${esc(Quality.monthName(-1))}</span></div>
      </div>`;

    const trendCard = `
      <section class="card dash-card qc-span2 qc-trendcard">
        <header class="dash-card-head"><h3>Check volume &amp; rolling pass rate</h3>
          <div class="qc-legend"><i class="lg good"></i><span>pass</span><i class="lg bad"></i><span>fail</span><i class="lg line"></i><span>rolling rate</span><span class="muted">· ${esc(Quality.month)}</span></div></header>
        ${trend.length ? Quality.trendSvg(trend) : '<div class="qc-empty"><span class="qc-e-ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M8.5 12.5l2.4 2.4 4.6-5"/></svg></span><strong>No checks recorded</strong><span class="muted">Nothing was inspected in ' + esc(Quality.month) + ' yet — run a review from the QC bench.</span></div>'}
        <div class="qc-tip" hidden></div>
      </section>`;

    const donutCard = `
      <section class="card dash-card">
        <header class="dash-card-head"><h3>Good vs wrong</h3><span class="muted">${esc(Quality.month)}</span></header>
        ${tot ? `
        <div class="donut-wrap qc-donut-wrap">
          <div class="qc-donut-stage">
            ${Quality.donutSvg(pass, fail, rate)}
            <div class="qc-donut-c">
              <span class="dc-v" data-count="${rate.toFixed(2)}" data-dec="2" data-suffix="%">0.00%</span>
              <span class="dc-l">first-pass</span>
              ${prevRate == null ? '<span class="dc-d na">no prev data</span>' : `<span class="dc-d ${rate - prevRate >= 0 ? 'good' : 'bad'}">${(rate - prevRate >= 0 ? '▲ +' : '▼ −') + Math.abs(rate - prevRate).toFixed(2)} pp</span>`}
            </div>
          </div>
          <ul class="donut-legend qc-dleg">
            <li data-seg="pass"><i class="lg good"></i><span>Passed</span><strong data-count="${pass}">0</strong><em>${tot ? Math.round((pass / tot) * 100) : 0}%</em></li>
            <li data-seg="fail"><i class="lg bad"></i><span>Failed</span><strong data-count="${fail}">0</strong><em>${tot ? Math.round((fail / tot) * 100) : 0}%</em></li>
            <li data-seg="prev"><i class="lg mute"></i><span>Prev month</span><strong>${Quality.pct(prevRate)}</strong></li>
          </ul>
        </div>
        ${(() => {
          const days = trend.filter((t) => (t.pass + t.fail) > 0)
            .map((t) => ({ d: t.day.slice(8), r: (t.pass / (t.pass + t.fail)) * 100 }));
          if (!days.length) return '';
          const best = days.reduce((a, b) => (b.r > a.r ? b : a));
          const worstD = days.reduce((a, b) => (b.r < a.r ? b : a));
          return `<div class="qc-donut-foot">
            <div class="best"><span>best day</span><strong>${best.d} · ${best.r.toFixed(0)}%</strong></div>
            <div class="worst"><span>worst day</span><strong>${worstD.d} · ${worstD.r.toFixed(0)}%</strong></div>
            <div><span>checks / day</span><strong>${(tot / trend.length).toFixed(1)}</strong></div>
          </div>`;
        })()}` : '<div class="qc-empty"><span class="qc-e-ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M3 12a9 9 0 1 0 9-9"/><path d="M3 12l3-3m-3 3l3 3"/></svg></span><strong>Nothing checked yet</strong><span class="muted">The pass/fail split appears once the first check lands.</span></div>'}
      </section>`;

    const tableCard = `
      <section class="card dash-card qc-span2">
        <header class="dash-card-head"><h3>Rework per tech</h3><span class="muted">who the fails landed on, ${esc(Quality.month)}</span></header>
        ${rows.length ? `
        <div class="qc-scroll">
        <table class="dash-table qc-table">
          <thead><tr><th>Tech</th><th class="num">Checks</th><th class="num">Pass</th><th class="num">Fail</th><th class="num">Fail %</th><th class="num">vs prev</th><th class="qc-sparkhead">fail % · 6 mo</th><th class="qc-barcol">fail share</th><th></th></tr></thead>
          <tbody>${rows.map((r, i) => {
            const t = r.pass + r.fail;
            const fp = t ? (r.fail / t) * 100 : 0;
            return `<tr style="animation-delay:${i * 45}ms">
              <td class="qc-tech"><span class="qc-ava">${esc((name(r.username) || '?').trim().charAt(0).toUpperCase())}</span><span class="qc-tech-n">${esc(name(r.username))}</span></td>
              <td class="num">${t}</td>
              <td class="num">${r.pass}</td>
              <td class="num ${r.fail ? 'strong bad-num' : ''}">${r.fail}</td>
              <td class="num">${fp.toFixed(2)}%</td>
              <td class="num">${r.prevRate == null ? '<span class="qc-delta na">new</span>' : Quality.deltaHtml(fp, 100 - r.prevRate, ' pp', true)}</td>
              <td class="qc-sparkcell">${Quality.sparkSvg(r.spark || [], { cls: 'sp-bad', w: 76, h: 22 })}</td>
              <td class="qc-barcol"><span class="qc-minibar"><i style="width:${((r.fail / maxFail) * 100).toFixed(0)}%;animation-delay:${i * 45 + 120}ms"></i></span></td>
              <td>${r.username === worst ? '<span class="badge sla-BREACHED"><span class="dot"></span>most rework</span>' : ''}</td>
            </tr>`;
          }).join('')}</tbody>
        </table></div>` : '<div class="qc-empty"><span class="qc-e-ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M8.5 12.5l2.4 2.4 4.6-5"/></svg></span><strong>No checks recorded</strong><span class="muted">Nothing was inspected in ' + esc(Quality.month) + ' yet — run a review from the QC bench.</span></div>'}
      </section>`;

    const reasonCard = `
      <section class="card dash-card">
        <header class="dash-card-head"><h3>Why it fails</h3><span class="muted">top reasons, ${esc(Quality.month)}</span></header>
        ${reasons.length ? `<ul class="qc-reasons">${reasons.map((r, i) => `
          <li style="animation-delay:${i * 50}ms">
            <div class="qc-r-head"><span>${esc(r.reason)}</span><strong>${r.count}</strong></div>
            <span class="qc-r-bar"><i style="width:${((r.count / maxReason) * 100).toFixed(0)}%;animation-delay:${i * 50 + 80}ms"></i></span>
          </li>`).join('')}</ul>` : '<div class="qc-empty"><span class="qc-e-ico ok"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M5 12.5l4.2 4.2L19 7"/></svg></span><strong>Clean month</strong><span class="muted">No fails recorded — nothing to explain.</span></div>'}
      </section>`;

    const feedCard = `
      <section class="card dash-card qc-span3">
        <header class="dash-card-head"><h3>Latest checks</h3><span class="muted">newest first · inspector → tech · ←/→ switches month</span></header>
        ${recent.length ? `<ul class="qc-feed">${recent.map((r, i) => `
          <li style="animation-delay:${i * 40}ms">
            <span class="qc-feed-dot ${r.status === 'PASS' ? 'ok' : 'no'}"></span>
            <span class="mono qc-feed-order">${esc(r.orderNumber)}</span>
            <span class="qc-feed-who">${esc(name(r.tech))}</span>
            <span class="muted qc-feed-insp">by ${esc(name(r.inspector))}</span>
            ${r.reason ? `<span class="qc-feed-reason">${esc(r.reason)}</span>` : '<span class="qc-feed-reason ok-t">clean pass</span>'}
            <span class="muted qc-feed-when">${esc(relTime(new Date(r.at).toISOString()))}</span>
          </li>`).join('')}</ul>` : '<div class="qc-empty"><span class="qc-e-ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M8.5 12.5l2.4 2.4 4.6-5"/></svg></span><strong>No checks recorded</strong><span class="muted">Nothing was inspected in ' + esc(Quality.month) + ' yet — run a review from the QC bench.</span></div>'}
      </section>`;

    const box = $('#quality-content');
    const enterCls = dir > 0 ? 'enter-next' : dir < 0 ? 'enter-prev' : '';
    box.innerHTML = `<div class="qc-wrap ${enterCls}">${kpis}<div class="dash-grid qc-grid">${trendCard}${donutCard}${tableCard}${reasonCard}${feedCard}</div></div>`;
    hydrateCounts(box);
    Quality.bindTip(box);
    Quality.bindDonut(box, { pass, fail, rate, prevRate });

    // animate donut arc + rolling-rate line + sparklines once mounted
    requestAnimationFrame(() => {
      const arcs = box.querySelectorAll('.qc-donut-arc, .seg-fail');
      arcs.forEach((arc) => {
      if (arc && arc.getTotalLength) {
        const len = arc.getTotalLength();
        if (len) {
          const target = arc.getAttribute('stroke-dasharray');
          arc.style.strokeDasharray = `0 ${len}`;
          arc.getBoundingClientRect();
          arc.style.transition = 'stroke-dasharray 900ms cubic-bezier(.22,.9,.28,1)';
          requestAnimationFrame(() => { arc.style.strokeDasharray = target; });
        }
      }
      })
      box.querySelectorAll('.qc-line, .qc-spark path').forEach((line) => {
        if (!line.getTotalLength) return;
        const L = line.getTotalLength();
        line.style.strokeDasharray = L;
        line.style.strokeDashoffset = L;
        line.getBoundingClientRect();
        line.style.transition = 'stroke-dashoffset 1000ms cubic-bezier(.35,.8,.3,1) 200ms';
        requestAnimationFrame(() => { line.style.strokeDashoffset = '0'; });
      });
    });
  },

  bindTip(box) {
    const card = box.querySelector('.qc-trendcard');
    const tip = box.querySelector('.qc-tip');
    const svg = box.querySelector('.qc-trend');
    if (!card || !tip || !svg) return;
    svg.addEventListener('pointermove', (e) => {
      const r = e.target.closest('rect[data-d]');
      if (!r) { tip.hidden = true; return; }
      const cb = card.getBoundingClientRect();
      tip.innerHTML = `<strong>${r.dataset.d}</strong><span>${r.dataset.p} pass · ${r.dataset.f} fail</span><em>rolling ${r.dataset.r}%</em>`;
      tip.hidden = false;
      const x = Math.min(Math.max(e.clientX - cb.left + 14, 8), cb.width - 150);
      const y = Math.min(Math.max(e.clientY - cb.top - 14, 8), cb.height - 70);
      tip.style.transform = `translate(${x}px, ${y}px)`;
    });
    svg.addEventListener('pointerleave', () => { tip.hidden = true; });
  },
};

window.Quality = Quality;

$('#qc-prev').addEventListener('click', () => Quality.shift(-1));
$('#qc-next').addEventListener('click', () => Quality.shift(1));

document.addEventListener('keydown', (e) => {
  if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') return;
  const pane = $('#view-quality');
  if (!pane || pane.classList.contains('hidden')) return;
  const t = document.activeElement;
  if (t && /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName)) return;
  if (!$('#modal-root').classList.contains('hidden') || !$('#palette-root').classList.contains('hidden')) return;
  if (e.key === 'ArrowLeft') Quality.shift(-1); else Quality.shift(1);
});
