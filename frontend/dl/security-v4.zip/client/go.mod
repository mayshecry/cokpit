module esprit-client

go 1.22


