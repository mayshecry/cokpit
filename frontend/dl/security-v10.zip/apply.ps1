param(
  [Parameter(Mandatory=$true)][string]$RepoRoot,
  [string]$OutExe = "cockpit.exe"
)

$ErrorActionPreference = "Stop"
$src = Split-Path -Parent $MyInvocation.MyCommand.Path

if (-not (Test-Path "$RepoRoot\go.mod")) {
  throw "Repo root '$RepoRoot' doesn't look right (go.mod missing)."
}
$go = Get-Command go -ErrorAction SilentlyContinue
if (-not $go) { throw "Go toolchain not found on PATH. Install Go first." }

$ts = Get-Date -Format "yyyyMMdd-HHmmss"
$backupDir = "$RepoRoot\backup-security-v10-$ts"
New-Item -ItemType Directory -Path $backupDir | Out-Null

# Everything we replace, in one list. The database (cockpit.db) and the
# pairing key store (clientkeys.json) are NEVER touched.
$toReplace = @('main.go','go.mod','go.sum','README.md','docs','pkg','frontend','client','test.sh')
foreach ($item in $toReplace) {
  $dst = "$RepoRoot\$item"
  $srcItem = "$src\$item"
  if (-not (Test-Path $srcItem)) { Write-Host "skip (not in package): $item"; continue }
  if (Test-Path $dst) {
    Move-Item $dst "$backupDir\$item"
  }
  Copy-Item $srcItem $dst -Recurse
  Write-Host "updated: $item"
}

Push-Location $RepoRoot
try {
  Write-Host "building..."
  & go build -mod=mod -o $OutExe .
  if ($LASTEXITCODE -ne 0) { throw "go build failed" }
} finally {
  Pop-Location
}

Write-Host ""
Write-Host "OK — security patch applied and rebuilt to $RepoRoot\$OutExe" -ForegroundColor Green
Write-Host "Backup of the previous state: $backupDir"
Write-Host "Restart the app: stop the old process, then start it again: .\$OutExe"
Write-Host "Useful env vars: `$env:PORT='8080'   `$env:COCKPIT_CLIENT_ONLY='1'  (UI only for paired Esprit ICT clients)"
Write-Host "Domain/HTTPS: `$env:COCKPIT_PUBLIC_URL='https://cockpit.example.nl'   `$env:COCKPIT_TRUST_PROXY='1'"
Write-Host "Native TLS:   `$env:PORT='443' `$env:TLS_CERT_FILE='C:\path\cert.pem' `$env:TLS_KEY_FILE='C:\path\key.pem'"
Write-Host ""
Write-Host "Client launcher (client-only mode): cd \`"$RepoRoot\client\`"; go mod tidy; go build -ldflags='-H windowsgui' -o CockpitClient.exe ."
Write-Host "First run with COCKPIT_CLIENT_ONLY=1 prints the one-time PAIRING CODE in the console (re-printed on every restart)."
