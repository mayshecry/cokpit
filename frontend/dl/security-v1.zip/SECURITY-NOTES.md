# Security patch v1 — what changed

## Runtime hardening (pkg/api/security.go, server.go)
- **Security headers on every response**: strict Content-Security-Policy
  (scripts: self + cdnjs; styles: self + inline; no framing), nosniff,
  X-Frame-Options: DENY, Referrer-Policy: same-origin, restrictive
  Permissions-Policy, Cross-Origin-Resource-Policy, and HSTS once TLS is on.
- **Cross-origin mutation guard**: POST/PUT/PATCH/DELETE requests that send
  an Origin header for a different host get 403.

## Login protection (auth_handlers.go, security.go)
- **Fixed-window brute-force limiter** (in-memory, zero new dependencies):
  - per account + IP: 5 attempts / 5 minutes
  - per IP overall: 20 attempts / minute
  - responds HTTP 429 with Retry-After
  - counter resets on successful login, so legitimate users never lock out.

## Password policy (users_handlers.go, security.go)
- New users: minimum 10 chars, must contain letters and at least one
  digit or symbol, and must not equal the username.

Verified end-to-end with the UI regression battery.
